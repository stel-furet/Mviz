# Creating Freque Plugins with Claude v2.0

**Complete guide for using Claude to create audio-reactive visualizations**

---

## What's New in v2.0

- **Video Reflection Prompting** - How to request cube camera systems
- **Advanced Three.js Requests** - Complex 3D scene prompting
- **Performance Considerations** - Asking for optimized implementations
- **Dual Mode Patterns** - Requesting multiple rendering modes

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [The Universal Plugin Prompt](#the-universal-plugin-prompt)
3. [Requesting Three.js Plugins](#requesting-threejs-plugins)
4. [Video Reflection Systems](#video-reflection-systems)
5. [Common Request Patterns](#common-request-patterns)
6. [Troubleshooting](#troubleshooting)

---

# Quick Start

## Your First Plugin in 10 Minutes

### Step 1: Copy the Template

```
Claude, create a Freque plugin:

Plugin Name: particleburst
Type: 2D Canvas

Visual Description:
Colorful particles that burst outward from the center on beat drops.

Audio Reactivity:
- Bass: Triggers particle bursts
- Mid: Controls particle speed
- Treble: Changes particle colors

Controls:
- Particle Count: slider, 50-500, default 200
- Burst Size: slider, 1.0-5.0, default 2.0
- Color Scheme: dropdown, [Rainbow, Warm, Cool, Monochrome]

Presets:
1. Gentle: Small bursts, slow speed, cool colors
2. Intense: Large bursts, fast speed, warm colors
```

### Step 2: Send to Claude

Copy the filled template and send it. Claude will generate complete, working code.

### Step 3: Save the File

Save as `particleburst-freque-plugin.js` in the `js/plugins/` directory.

### Step 4: Reload Freque

Refresh your browser. The plugin appears in the mixer!

---

# The Universal Plugin Prompt

## Complete Template

```
Claude, help me create a Freque plugin:

═══════════════════════════════════════
BASIC INFO
═══════════════════════════════════════
Plugin Name: [one-word-or-hyphenated]
Type: [2D Canvas / 3D Three.js / Shader-based]
Description: [one sentence description]

═══════════════════════════════════════
VISUAL DESCRIPTION
═══════════════════════════════════════
Main Elements:
[Describe what you see - particles, shapes, lines, etc.]

Movement Style:
[How things move - float, spin, pulse, wave, etc.]

Color Scheme:
[Colors and how they change with audio]

Layout:
[Where things appear - center, edges, random, grid, etc.]

Special Effects:
[Any special visual effects - glow, trails, fade, blur, etc.]

═══════════════════════════════════════
AUDIO REACTIVITY
═══════════════════════════════════════
Bass Response (Low Frequencies):
[What bass affects - size, quantity, movement speed, etc.]

Mid Response (Mid Frequencies):
[What mids affect - rotation, color, spread, etc.]

Treble Response (High Frequencies):
[What treble affects - brightness, detail, shimmer, etc.]

Beat Detection:
[What happens on beat drops - burst, pulse, flash, etc.]

═══════════════════════════════════════
CONTROLS
═══════════════════════════════════════
Sliders:
- [Name]: [min]-[max], default [value], [what it controls]
- [Name]: [min]-[max], default [value], [what it controls]

Dropdowns:
- [Name]: [option1, option2, option3...], [what it controls]

Checkboxes:
- [Name]: [what it toggles on/off]

Buttons:
- [Name]: [what it does when clicked]

═══════════════════════════════════════
PRESETS (minimum 2)
═══════════════════════════════════════
Preset 1 - [Name]:
Purpose: [What music/mood this suits]
Settings: [Key control values]

Preset 2 - [Name]:
Purpose: [What music/mood this suits]
Settings: [Key control values]

Preset 3 - [Name] (optional):
Purpose: [What music/mood this suits]
Settings: [Key control values]

═══════════════════════════════════════
SPECIAL REQUESTS
═══════════════════════════════════════
[Any specific techniques, technologies, references]
[Performance requirements]
[Compatibility needs]
```

---

# Requesting Three.js Plugins

## Basic Three.js Request

```
Claude, create a Three.js plugin for Freque:

Plugin Name: floatingspheres
Type: 3D Three.js

Create floating metallic spheres that reflect the video/background.
Use proper Freque Three.js setup with:
- Container-based sizing (not canvas buffer)
- Individual CSS property assignment
- Proper environment mapping from video or background image
```

## Important: Three.js Setup Requirements

**ALWAYS include this in Three.js requests:**

```
CRITICAL Three.js Requirements:
1. Get dimensions from #visualizationContainer element
2. Use manual CSS property assignment (NOT cssText copying)
3. Set canvas CSS to width: 100% and height: 100%
4. Use devicePixelRatio for high-DPI displays
5. Set output encoding to sRGBEncoding
```

Claude has been trained on these patterns and will implement them correctly.

---

# Video Reflection Systems

## When to Request Cube Cameras

If you want **video reflections on chrome/metallic surfaces**, you MUST request a cube camera system:

```
Claude, create a Three.js plugin with chrome spheres reflecting the video.

IMPORTANT: 
- Use cube camera system for video reflections (required for Three.js r120+)
- Create inverted video sphere for cube camera to capture
- Update cube camera every frame to keep reflections synchronized
- Use layer management to hide/show video sphere
```

## Video Reflection Request Template

```
Claude, create a reflective metallic [object] plugin:

Technology Requirements:
- Three.js with cube camera system for video reflections
- Support both video (#bgVideo) and background image (#bgImage) sources
- Dual mode: direct texture AND chrome reflection
- Dynamic cube camera positioning for realistic reflections

Visual:
- [Describe your reflective objects]
- Chrome/metallic material
- Reflections show the video/background

Controls:
- Toggle between direct texture and reflection modes
- Toggle between video and background image sources
- Metalness: 0.0-1.0, default 1.0
- Roughness: 0.0-1.0, default 0.0
- Reflection Intensity: 0.0-3.0, default 0.5

Performance:
- Use shared cube camera (not per-object)
- 2048 cube map resolution for balance
- Only update cube camera when in reflection mode
```

## What Claude Will Implement

When you request a video reflection system, Claude will create:

1. **Cube Render Target**
   - High resolution (2048 or 4096)
   - RGBA format with mipmaps
   - sRGB encoding

2. **Cube Camera**
   - Positioned strategically (often at origin or average object position)
   - Enabled to see hidden layer
   - Updates every frame

3. **Large Inverted Video Sphere**
   - 500 unit radius
   - Video texture with EquirectangularReflectionMapping
   - Hidden from main camera via layer system
   - Proper rotation for correct reflections

4. **Material Setup**
   - envMap using cube map texture
   - High metalness (0.8-1.0)
   - Low roughness (0.0-0.2)
   - Adjustable envMapIntensity

5. **Update Loop**
   - Video texture needsUpdate every frame
   - Cube camera update when in reflection mode
   - Temporary object hiding during capture

## Cube Camera Prompting Examples

### Example 1: Chrome Spheres

```
Claude, create chrome spheres that reflect the video input.

Requirements:
- Use cube camera for video reflections
- Support both video and background image
- Dynamic cube camera positioning (average sphere position)
- Layer system to hide/show video sphere
- Proper sRGB encoding throughout

Spheres:
- 10-30 spheres
- Floating animation
- Audio-reactive size (bass)
- Ultra chrome appearance
```

### Example 2: Reflective Floor

```
Claude, create a reflective floor plugin showing video reflections.

Requirements:
- Large plane geometry for floor
- Cube camera positioned above floor
- Video sphere for reflections
- Support toggling between mirror and matte

Floor:
- Positioned below camera view
- PBR material (metalness + roughness)
- Grid lines for reference
- Audio-reactive ripple effect
```

### Example 3: Mirror Ball

```
Claude, create a disco mirror ball with video reflections.

Requirements:
- Single large sphere at center
- Cube camera at sphere center
- Ultra-high quality reflections (4096 cube map)
- Rotation animation
- Beat-reactive spin speed
```

## Performance Considerations

### Requesting Optimized Cube Cameras

```
Claude, create [plugin] with video reflections.

Performance Requirements:
- Use shared cube camera (not per-object)
- 1024 or 2048 cube map resolution
- Update cube camera every other frame
- Only update when video is playing
- Dispose resources properly in cleanup
```

### Quality vs Performance Trade-off

You can specify:

```
Cube Map Quality:
- 4096 resolution for ultra quality (expensive)
- 2048 resolution for high quality (balanced)  ← RECOMMENDED
- 1024 resolution for good quality (performance)

Update Frequency:
- Every frame for perfect sync (expensive)
- Every 2-3 frames for good balance  ← RECOMMENDED
- Every 5 frames for performance
```

---

# Common Request Patterns

## 2D Canvas Plugins

### Particle Systems

```
Claude, create a 2D particle system:

Particles:
- 500-2000 particles
- Emit from center/edges/random
- Float/drift/burst patterns
- Size based on bass
- Color based on treble
- Fade trails for motion blur

Audio:
- Bass triggers emission
- Mids control speed
- Treble affects color

Controls:
- Particle count
- Emission rate
- Particle lifetime
- Trail length
- Color scheme
```

### Waveforms

```
Claude, create an audio waveform visualizer:

Waveform:
- Circular/linear layout
- Smooth curves
- Line or bar style
- Gradient colors
- Glow effect

Audio:
- Use actual waveform data
- Bass emphasizes low frequencies
- Treble emphasizes high frequencies

Controls:
- Waveform style (line/bars)
- Color scheme
- Thickness
- Smoothing
```

## 3D Three.js Plugins

### Geometric Shapes

```
Claude, create 3D geometric shapes:

Shapes:
- Cubes, spheres, toruses, etc.
- Multiple objects in scene
- Rotation animations
- Audio-reactive scale
- PBR materials

Controls:
- Shape type selector
- Material properties
- Animation speed
- Quantity
- Arrangement (grid/random/orbit)
```

### Tunnel/Corridor Effects

```
Claude, create a tunnel effect:

Tunnel:
- Repeating rings/segments
- Forward motion illusion
- Texture or geometric
- Audio pulses through tunnel
- Camera movement

Audio:
- Bass expands rings
- Beat creates pulse wave
- Treble affects texture detail
```

## Dual Mode Patterns

```
Claude, create a plugin with multiple render modes:

Modes:
1. Particles (2D canvas)
2. Geometry (3D Three.js)
3. Waveform (2D canvas)

Each mode:
- Shares same controls where applicable
- Different visual style
- Toggle between modes with button

Controls:
- Mode selector
- [Shared controls]
- [Mode-specific controls]
```

---

# Troubleshooting

## Common Issues and How to Ask Claude

### Issue: Video reflections not working

**Ask Claude:**
```
Claude, the video reflections aren't showing on my chrome spheres.
Can you:
1. Verify cube camera setup is correct
2. Check video sphere is on layer 1
3. Confirm cube camera update is in onRender
4. Check video element is playing
5. Verify sRGB encoding is consistent
```

### Issue: Canvas sizing wrong

**Ask Claude:**
```
Claude, the Three.js canvas isn't sizing correctly.
Please verify:
1. Using visualizationContainer for dimensions
2. Setting individual CSS properties (not cssText)
3. Using percentages for width/height
4. Setting devicePixelRatio properly
```

### Issue: Textures upside down

**Ask Claude:**
```
Claude, the video/image textures appear upside down.
Please:
1. Set flipY = true on textures
2. Remove any rotation-based fixes
3. Check mapping type is correct
```

### Issue: Button labels not updating

**Ask Claude:**
```
Claude, button labels aren't updating when I click them.
Please use direct DOM queries with data-control attributes:

const button = document.querySelector('[data-control="controlName"]');
button.textContent = newLabel;
```

### Issue: Performance problems

**Ask Claude:**
```
Claude, the plugin is running slowly.
Please optimize:
1. Reduce cube map resolution to 1024 or 2048
2. Use shared cube camera instead of per-object
3. Update cube camera every 2-3 frames
4. Check geometry complexity
5. Only update when necessary
```

---

# Advanced Prompting Techniques

## Iterative Development

### Start Simple

```
Claude, create a basic chrome sphere plugin with:
- One sphere at center
- Video reflections
- Size slider
- Audio-reactive scale
```

### Then Add Features

```
Claude, update the sphere plugin to:
- Add 5-20 spheres
- Random positions
- Floating animation
- Beat-reactive pulse
```

### Then Polish

```
Claude, enhance the plugin with:
- Dual mode (direct texture + reflection)
- Background sphere visibility toggle
- Dynamic cube camera positioning
- Performance optimizations
```

## Combining References

```
Claude, create a plugin combining:
- The cube camera system from Chrome Spheres
- The particle emission from [another plugin]
- The audio analysis from [another plugin]
- Custom visual style: [describe]
```

## Requesting Specific Technologies

```
Claude, create a plugin using:
- Three.js InstancedMesh for performance
- Custom GLSL shaders for effects
- Post-processing with bloom
- Advanced PBR materials
```

---

# Visual Description Library

## Movement Verbs

- **Float** - Gentle up/down motion
- **Drift** - Slow sideways motion
- **Pulse** - Rhythmic expand/contract
- **Spin** - Rotation on axis
- **Orbit** - Circle around point
- **Wave** - Undulating motion
- **Burst** - Sudden outward explosion
- **Spiral** - Circular with forward/back
- **Wobble** - Irregular shaking
- **Glide** - Smooth continuous motion

## Effect Words

- **Glow** - Soft light emanation
- **Trail** - Motion blur behind objects
- **Fade** - Gradual transparency
- **Shimmer** - Subtle sparkle
- **Ripple** - Expanding circular waves
- **Bloom** - Bright light overflow
- **Distortion** - Warped/twisted appearance
- **Reflection** - Mirror-like surface
- **Refraction** - Light bending
- **Dispersion** - Rainbow prismatic effect

## Color Descriptors

- **Gradient** - Smooth color transition
- **Vibrant** - Highly saturated
- **Pastel** - Soft, light colors
- **Monochrome** - Single color variations
- **Warm** - Reds, oranges, yellows
- **Cool** - Blues, greens, purples
- **Neon** - Bright, glowing colors
- **Metallic** - Chrome, gold, silver
- **Iridescent** - Rainbow-shifting colors

## Layout Terms

- **Center-focused** - Emanating from middle
- **Edge-emphasized** - Action at borders
- **Grid** - Organized rows/columns
- **Random** - Unpredictable placement
- **Circular** - Ring arrangement
- **Radial** - Spoke pattern from center
- **Layered** - Multiple depth levels
- **Scattered** - Loosely distributed
- **Clustered** - Grouped together

---

# Real-World Examples

## Example 1: Chrome Spheres

**User Request:**
```
Claude, create floating chrome spheres that reflect the video/background.

Spheres:
- 15-20 spheres
- Different sizes
- Floating animation
- Chrome appearance

Video Reflections:
- Use cube camera system
- Support video and background image
- Toggle between texture modes
- Show/hide background sphere

Audio:
- Bass → size
- Mids → movement
- Treble → shininess
- Beat pulse

Controls:
- Sphere count: 1-50
- Size range: 5-10
- Float speed: 0-10
- Metalness: 0-1
- Roughness: 0-1
- Reflection intensity: 0-3
```

**Result:** Complete Chrome Spheres plugin with sophisticated cube camera system, dual modes, and full audio reactivity.

## Example 2: Energy Particles

**User Request:**
```
Claude, create an energy particle system:

Particles burst from center on beats, drift outward, and fade.
Colors shift with treble frequencies.
Bass determines burst intensity.
Mids control drift speed.

Controls:
- Particle count
- Burst size
- Lifetime
- Color scheme
- Trail length

2 Presets:
- Gentle: Small bursts, slow fade
- Explosive: Large bursts, fast fade
```

**Result:** Beautiful particle system with beat detection, color shifting, and smooth trails.

## Example 3: Tunnel Vision

**User Request:**
```
Claude, create a 3D tunnel effect:

Camera moves through infinite tunnel of rings.
Rings pulse with audio.
Texture or video on rings.
Bass makes tunnel expand.
Beat creates shockwave effect.

Modes:
- Geometric rings
- Textured panels
- Video mapped

Controls:
- Speed
- Ring spacing
- Texture/video source
- Pulse intensity
```

**Result:** Immersive 3D tunnel with multiple visual modes and strong audio reactivity.

---

# Tips for Success

## Do's

✅ **Be specific about visuals** - "Floating chrome spheres" is better than "3D objects"

✅ **Explain audio mapping** - Tell Claude exactly what affects what

✅ **Request proper Three.js setup** - Mention container sizing, CSS, encoding

✅ **Ask for cube cameras when needed** - For video reflections on metallic surfaces

✅ **Specify control types and ranges** - Give exact min/max values

✅ **Provide at least 2 presets** - Help define the plugin's range

✅ **Mention performance needs** - If targeting mobile or lower-end hardware

✅ **Ask questions if unclear** - Claude can help refine your vision

## Don'ts

❌ **Don't be vague** - "Make it cool" doesn't give enough guidance

❌ **Don't skip audio mapping** - Audio reactivity is core to Freque

❌ **Don't forget presets** - They're required for the plugin system

❌ **Don't ignore performance** - Mention if you need optimization

❌ **Don't assume** - Clearly state if you want video reflections

## Getting the Best Results

### 1. Start with Clear Vision
Think about what you want to see and how it should move.

### 2. Use the Template
The universal template ensures you cover everything.

### 3. Reference Examples
Mention other plugins or effects you like.

### 4. Iterate
Start simple, then ask Claude to add features.

### 5. Test and Refine
Try it, note issues, ask Claude to fix them.

---

# Conclusion

Claude is your partner in plugin creation. With clear descriptions and specific requirements, you can create professional-quality audio visualizations without deep coding knowledge.

**Remember:**
- Use the universal template
- Be specific about visuals and audio mapping
- Request proper Three.js setup for 3D plugins
- Ask for cube cameras when you want video reflections
- Start simple and iterate
- Don't hesitate to ask questions

**Happy creating! 🚀🎨🎵**

*Guide Version 2.0 - Updated with video reflection prompting*
