# Freque Plugin Documentation v2.0

**Complete documentation for advanced Three.js techniques in Freque, with comprehensive cube camera video reflection system**

---

## 📦 Documentation Package

### Total Size: ~82 KB
### Files: 5 comprehensive guides
### Version: 2.0 (November 8, 2025)

---

## 📚 Documentation Files

### 1️⃣ [UPDATE_SUMMARY.md](computer:///mnt/user-data/outputs/UPDATE_SUMMARY.md) (16 KB)
**Start here! Complete overview of all updates.**

**Contents:**
- What was done
- Major concepts documented
- Key changes from previous documentation
- Chrome Spheres plugin analysis highlights
- For plugin developers (how to use these docs)
- Technical specifications
- Future considerations

**Who should read this:**
- Project managers wanting overview
- Developers new to the updated system
- Anyone wanting to understand what changed

---

### 2️⃣ [FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md](computer:///mnt/user-data/outputs/FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md) (26 KB)
**The complete technical reference for plugin developers.**

**Contents:**
- Quick Start (basic plugin template)
- Standard Three.js Integration
- **Cube Camera System for Video Reflections** ⭐ NEW
- Layer Management ⭐ NEW
- Color Space Management ⭐ NEW
- Dual Mapping Modes ⭐ NEW
- Audio Integration
- UI Controls
- Performance Optimization
- Best Practices

**Who should read this:**
- Developers manually coding plugins
- Anyone implementing Three.js features
- Technical leads architecting new plugins

**Key Sections:**
- **Cube Camera System** (Lines 150-450): Complete implementation guide
- **Advanced Three.js Techniques** (Lines 450-750): Layer management, color space, dynamic positioning
- **Performance Optimization** (Lines 900-1100): Resolution trade-offs, update frequency, shared cameras

---

### 3️⃣ [CREATING_PLUGINS_WITH_CLAUDE_V2.md](computer:///mnt/user-data/outputs/CREATING_PLUGINS_WITH_CLAUDE_V2.md) (19 KB)
**Guide for using Claude to create Freque plugins.**

**Contents:**
- Quick Start (10-minute first plugin)
- The Universal Plugin Prompt Template
- Requesting Three.js Plugins
- **Video Reflection Systems** ⭐ NEW
- Common Request Patterns
- Troubleshooting
- Visual Description Library
- Real-World Examples

**Who should read this:**
- Non-technical users wanting to create plugins
- Technical users who want to use Claude for faster development
- Anyone learning effective prompting for code generation

**Key Sections:**
- **Video Reflection Systems** (Lines 120-400): How to request cube camera implementations
- **Universal Plugin Prompt** (Lines 50-100): Complete template for any plugin
- **Troubleshooting** (Lines 650-750): How to ask Claude to fix common issues

---

### 4️⃣ [CHROMOSPHERES_ANALYSIS.md](computer:///mnt/user-data/outputs/CHROMOSPHERES_ANALYSIS.md) (12 KB)
**Deep dive into Chrome Spheres v1.2.0 → v1.3.0 changes.**

**Contents:**
- Executive Summary
- Major Architectural Changes
- Cube Camera System Implementation
- Dynamic Positioning
- Background Sphere Visibility
- Dual Texture System
- Color Space Management
- Enhanced Quality Settings
- Performance Optimizations
- Code Quality Improvements
- Architectural Lessons Learned

**Who should read this:**
- Developers wanting to understand the cube camera architecture
- Anyone curious about the technical evolution
- Developers maintaining or extending Chrome Spheres
- Technical leads evaluating the approach

**Key Insights:**
- Why cube cameras are required for video reflections
- How dynamic positioning works
- Performance vs quality trade-offs
- Lessons applicable to other plugins

---

### 5️⃣ [CUBE_CAMERA_QUICK_REFERENCE.md](computer:///mnt/user-data/outputs/CUBE_CAMERA_QUICK_REFERENCE.md) (9 KB)
**One-page quick reference for cube camera implementation.**

**Contents:**
- When to Use Cube Cameras
- 5-Step Implementation (copy-paste ready)
- Advanced: Dynamic Positioning
- Layer System
- Performance Optimization
- Common Issues & Solutions
- Selectors
- Complete Minimal Example
- Asking Claude Template
- Memory and Render Costs

**Who should read this:**
- Developers implementing cube cameras RIGHT NOW
- Quick reference during coding
- Troubleshooting guide
- Template for Claude requests

**Best For:**
- "How do I implement this quickly?"
- "What's the minimal code needed?"
- "How do I ask Claude for this?"

---

## 🎯 Quick Navigation Guide

### I want to...

**...understand what changed overall**
→ Read [UPDATE_SUMMARY.md](computer:///mnt/user-data/outputs/UPDATE_SUMMARY.md)

**...implement cube cameras myself**
→ Read [FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md](computer:///mnt/user-data/outputs/FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md) sections on Cube Camera System

**...use Claude to create a plugin with video reflections**
→ Read [CREATING_PLUGINS_WITH_CLAUDE_V2.md](computer:///mnt/user-data/outputs/CREATING_PLUGINS_WITH_CLAUDE_V2.md) Video Reflection Systems section

**...understand why Chrome Spheres works the way it does**
→ Read [CHROMOSPHERES_ANALYSIS.md](computer:///mnt/user-data/outputs/CHROMOSPHERES_ANALYSIS.md)

**...quickly implement cube cameras right now**
→ Use [CUBE_CAMERA_QUICK_REFERENCE.md](computer:///mnt/user-data/outputs/CUBE_CAMERA_QUICK_REFERENCE.md)

**...see a working example**
→ Study `chromospheres-freque-plugin.js` (see Quick Reference for line numbers)

---

## 🔑 Key Concepts

### Cube Camera System

**What:** A technique for capturing 6-sided environment maps from a video sphere to enable video reflections on metallic surfaces.

**Why:** Three.js r120+ doesn't support direct video textures with EquirectangularReflectionMapping for environment maps.

**How:** 
1. Create inverted sphere textured with video
2. Position cube camera to capture this sphere
3. Generate cube map texture every frame
4. Apply cube map as environment map on materials

**Where Documented:**
- Full guide: Development Guide, Cube Camera System section
- Quick implementation: Quick Reference
- Theory: Chrome Spheres Analysis
- Prompting: Claude Guide, Video Reflection Systems

### Dynamic Positioning

**What:** Moving the cube camera to the average position of all reflective objects.

**Why:** Creates more realistic reflections that change based on object positions.

**Performance:** Same cost as fixed position (6 render passes per frame).

**Where Documented:**
- Implementation: Development Guide, Advanced Techniques
- Code example: Quick Reference, Advanced section

### Layer Management

**What:** Using Three.js layer system to control visibility to different cameras.

**How:**
- Layer 0: Visible to main camera (user sees)
- Layer 1: Hidden from main camera (cube camera sees)

**Why:** Elegantly handles showing/hiding video sphere without manual toggling.

**Where Documented:**
- Guide: Development Guide, Layer Management section
- Quick ref: Quick Reference, Layer System

### sRGB Color Space

**What:** Ensuring consistent color space throughout the rendering pipeline.

**Why:** Makes video reflections match background image reflections in brightness and color.

**Where:** Renderer, cube render target, video textures all use sRGBEncoding.

**Where Documented:**
- Theory: Chrome Spheres Analysis, Color Space section
- Implementation: Development Guide, Color Space Management

---

## 📊 Documentation Statistics

### Coverage

✅ **Cube Camera System:** Complete implementation guide  
✅ **Layer Management:** Full documentation  
✅ **Color Space:** Best practices established  
✅ **Dynamic Positioning:** Implementation and theory  
✅ **Performance:** Optimization strategies  
✅ **Prompting:** Claude request patterns  
✅ **Troubleshooting:** Common issues addressed  
✅ **Examples:** Chrome Spheres as reference  

### Audience Coverage

✅ **Non-Technical Users:** Claude Guide with templates  
✅ **Junior Developers:** Step-by-step implementation guides  
✅ **Senior Developers:** Architecture analysis and theory  
✅ **Technical Leads:** Performance considerations and trade-offs  

### Format Coverage

✅ **Quick Start:** 10-minute plugin tutorial  
✅ **Reference:** Comprehensive technical documentation  
✅ **Quick Reference:** One-page implementation guide  
✅ **Analysis:** Deep architectural dive  
✅ **Prompting:** Claude request templates  

---

## 🚀 Getting Started Paths

### Path 1: Non-Technical User
1. Read "Quick Start" in [CREATING_PLUGINS_WITH_CLAUDE_V2.md](computer:///mnt/user-data/outputs/CREATING_PLUGINS_WITH_CLAUDE_V2.md)
2. Copy the Universal Plugin Prompt template
3. Fill in your vision
4. Send to Claude
5. Save and test the result

**Time:** 15 minutes to first plugin

---

### Path 2: Developer Creating First Plugin
1. Read "Quick Start" in [FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md](computer:///mnt/user-data/outputs/FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md)
2. Copy basic plugin template
3. Implement onInitialize, onUpdate, onRender
4. Add controls and presets
5. Test and iterate

**Time:** 30 minutes to basic plugin, 2-4 hours to polished plugin

---

### Path 3: Developer Adding Video Reflections
1. Scan [UPDATE_SUMMARY.md](computer:///mnt/user-data/outputs/UPDATE_SUMMARY.md) for overview
2. Read Cube Camera System section in [FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md](computer:///mnt/user-data/outputs/FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md)
3. Use [CUBE_CAMERA_QUICK_REFERENCE.md](computer:///mnt/user-data/outputs/CUBE_CAMERA_QUICK_REFERENCE.md) during implementation
4. Study Chrome Spheres plugin code for details
5. Test performance and optimize

**Time:** 1-2 hours for first implementation

---

### Path 4: Technical Lead Evaluating Approach
1. Read [UPDATE_SUMMARY.md](computer:///mnt/user-data/outputs/UPDATE_SUMMARY.md) executive summary
2. Read [CHROMOSPHERES_ANALYSIS.md](computer:///mnt/user-data/outputs/CHROMOSPHERES_ANALYSIS.md) architectural section
3. Review performance considerations in [FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md](computer:///mnt/user-data/outputs/FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md)
4. Decide on cube map resolution and update frequency standards
5. Set performance benchmarks

**Time:** 30 minutes for evaluation

---

## 🎨 Visual Overview

```
Freque Plugin Documentation v2.0
│
├─ UPDATE_SUMMARY.md (Start Here!)
│  ├─ What was done
│  ├─ Key concepts
│  └─ How to use the docs
│
├─ FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md (Technical Reference)
│  ├─ Quick Start
│  ├─ Three.js Integration
│  ├─ Cube Camera System ⭐
│  ├─ Advanced Techniques ⭐
│  ├─ Audio Integration
│  └─ Performance
│
├─ CREATING_PLUGINS_WITH_CLAUDE_V2.md (Claude Prompting)
│  ├─ Quick Start
│  ├─ Universal Prompt
│  ├─ Video Reflections ⭐
│  ├─ Request Patterns
│  └─ Troubleshooting
│
├─ CHROMOSPHERES_ANALYSIS.md (Deep Dive)
│  ├─ Architectural Changes
│  ├─ Cube Camera Implementation
│  ├─ Performance Analysis
│  └─ Lessons Learned
│
└─ CUBE_CAMERA_QUICK_REFERENCE.md (Copy-Paste Guide)
   ├─ 5-Step Implementation
   ├─ Code Examples
   ├─ Common Issues
   └─ Minimal Example
```

---

## 🔗 External References

### Three.js Documentation
- [CubeCamera](https://threejs.org/docs/#api/en/cameras/CubeCamera)
- [WebGLCubeRenderTarget](https://threejs.org/docs/#api/en/renderers/WebGLCubeRenderTarget)
- [VideoTexture](https://threejs.org/docs/#api/en/textures/VideoTexture)
- [Layers](https://threejs.org/docs/#api/en/core/Layers)

### Freque Resources
- Chrome Spheres Plugin: `js/plugins/chromospheres-freque-plugin.js`
- Plugin Base Class: `js/plugin-base.js`
- Plugin Mixer: `js/plugin-mixer-integration.js`

---

## 📝 Version History

### v2.0 (November 8, 2025)
- Added cube camera system documentation
- Added layer management guide
- Added color space management
- Added dynamic positioning techniques
- Added video reflection prompting guide
- Updated all examples with v1.3.0 patterns
- Created quick reference card
- Created comprehensive analysis document

### v1.0 (Previous)
- Basic Three.js integration
- Standard canvas setup
- Audio integration
- UI controls
- 2D canvas patterns

---

## 🎯 Success Metrics

After reading this documentation, you should be able to:

✅ Explain why cube cameras are needed for video reflections  
✅ Implement a basic cube camera system  
✅ Use layers to control object visibility  
✅ Set up proper sRGB color space  
✅ Optimize cube camera performance  
✅ Request video reflections from Claude  
✅ Troubleshoot common cube camera issues  
✅ Understand the Chrome Spheres architecture  

---

## 🤝 Contributing

### Found an Issue?
- Create an issue with specific details
- Include code snippets if applicable
- Mention which document has the issue

### Want to Add Examples?
- Follow the established format
- Include complete, working code
- Explain key concepts
- Add performance notes

### Improving Documentation?
- Keep the clear, hierarchical structure
- Use code examples liberally
- Include "Why" not just "How"
- Consider different audience levels

---

## 📬 Support

### Questions About Implementation
- Check Quick Reference first
- Review relevant section in Development Guide
- Study Chrome Spheres plugin code
- Ask Claude with specific context

### Questions About Prompting
- Review Claude Guide examples
- Use provided templates
- Start simple and iterate
- Include performance requirements

### Performance Issues
- Check Performance Optimization section
- Review cube map resolution settings
- Consider update frequency
- Profile on target hardware

---

## 🎉 Conclusion

This documentation package provides everything needed to implement advanced Three.js techniques in Freque, particularly the sophisticated cube camera system required for video reflections in modern Three.js versions.

**Key Resources:**
- **Learning:** Start with UPDATE_SUMMARY.md
- **Reference:** FREQUE_PLUGIN_DEVELOPMENT_GUIDE_V2.md
- **Quick Impl:** CUBE_CAMERA_QUICK_REFERENCE.md
- **Prompting:** CREATING_PLUGINS_WITH_CLAUDE_V2.md
- **Theory:** CHROMOSPHERES_ANALYSIS.md

**Total Package:** 82 KB of comprehensive, production-ready documentation

---

**Happy plugin development! 🚀🎨🎵**

*Documentation v2.0 - Based on Chrome Spheres Plugin v1.3.0*
*Last Updated: November 8, 2025*
