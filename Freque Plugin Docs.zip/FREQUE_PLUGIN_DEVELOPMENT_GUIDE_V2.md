# Freque Plugin Development Guide v2.0

**Complete guide for creating audio-reactive visualizations with advanced Three.js techniques**

---

## What's New in v2.0

- **Cube Camera Video Reflection System** - Complete implementation guide
- **Layer Management** - Selective visibility for complex scenes  
- **Color Space Management** - sRGB encoding best practices
- **Dynamic Environment Mapping** - Position-based reflections
- **Performance Optimization** - Strategies for complex 3D scenes

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Three.js Integration](#threejs-integration)
3. [Advanced Three.js Techniques](#advanced-threejs-techniques)
4. [Audio Integration](#audio-integration)
5. [UI Controls](#ui-controls)
6. [Performance Optimization](#performance-optimization)
7. [Best Practices](#best-practices)

---

# Quick Start

## Basic Plugin Template

```javascript
class MyPlugin extends FrequePluginBase {
    constructor(visualizer) {
        super('myplugin', visualizer, {
            version: '1.0.0',
            author: 'Your Name',
            description: 'My Awesome Plugin',
            targetFPS: 60
        });
        
        this.setupControls();
        this.setupPresets();
    }
    
    setupControls() {
        this.addControl('size', {
            type: 'slider',
            label: 'Size',
            min: 1,
            max: 100,
            value: 50,
            onChange: (value) => {
                this.size = value;
            }
        });
    }
    
    setupPresets() {
        this.addPreset('default', {
            name: 'Default',
            values: { size: 50 }
        });
    }
    
    onInitialize() {
        // Setup your visualization
    }
    
    onUpdate(deltaTime, timestamp, sharedAudioData) {
        // Update logic
        const energy = this.getAudioEnergy();
    }
    
    onRender(deltaTime, timestamp, sharedAudioData) {
        // Draw to canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

// Auto-register
setTimeout(() => {
    if (window.visualizer && window.FrequePluginBase) {
        new MyPlugin(window.visualizer);
    }
}, 500);
```

---

# Three.js Integration

## Standard Three.js Setup

### Step 1: Get Container Dimensions

**CRITICAL:** Always get size from `visualizationContainer`, NOT canvas buffer.

```javascript
onInitialize() {
    // Get dimensions from container
    const container = document.getElementById('visualizationContainer');
    const rect = container.getBoundingClientRect();
    const width = rect.width || window.innerWidth;
    const height = rect.height || window.innerHeight;
    
    console.log(`Container dimensions: ${width}x${height}`);
}
```

### Step 2: Create Scene and Camera

```javascript
// Create scene
this.scene = new THREE.Scene();

// Create camera with container aspect ratio
this.camera = new THREE.PerspectiveCamera(
    75,
    width / height,
    0.1,
    1000
);
this.camera.position.z = 20;
```

### Step 3: Create Renderer

```javascript
this.renderer = new THREE.WebGLRenderer({
    alpha: true,
    antialias: true,
    preserveDrawingBuffer: true
});

// Set pixel ratio for high-DPI displays
this.renderer.setPixelRatio(window.devicePixelRatio);

// Use container dimensions
this.renderer.setSize(width, height);

// Set color space (important for matching Freque's visuals)
if (this.renderer.outputEncoding !== undefined) {
    this.renderer.outputEncoding = THREE.sRGBEncoding;
}
```

### Step 4: Setup Canvas CSS

**CRITICAL:** Set CSS properties individually, NOT with cssText.

```javascript
const threeCanvas = this.renderer.domElement;
threeCanvas.id = this.canvasId;
threeCanvas.className = this.canvas.className;

// Set each CSS property individually
threeCanvas.style.position = 'absolute';
threeCanvas.style.top = '0';
threeCanvas.style.left = '0';
threeCanvas.style.width = '100%';    // Percentage, not pixels
threeCanvas.style.height = '100%';   // Percentage, not pixels
threeCanvas.style.pointerEvents = 'none';
threeCanvas.style.zIndex = this.canvas.style.zIndex || this.zIndex.toString();
threeCanvas.style.display = this.canvas.style.display || 'block';
threeCanvas.style.opacity = this.canvas.style.opacity || '1';
```

### Step 5: Replace Canvas in DOM

```javascript
if (this.canvas.parentNode) {
    this.canvas.parentNode.replaceChild(threeCanvas, this.canvas);
}
this.canvas = threeCanvas;
```

### Step 6: Add Lighting

```javascript
// Ambient light for overall illumination
const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
this.scene.add(ambientLight);

// Directional lights for reflections
const light1 = new THREE.DirectionalLight(0xffffff, 1.0);
light1.position.set(10, 10, 10);
this.scene.add(light1);

const light2 = new THREE.DirectionalLight(0xffffff, 0.6);
light2.position.set(-10, -10, -10);
this.scene.add(light2);
```

---

# Advanced Three.js Techniques

## Video/Background Textures

### Finding Video Element

```javascript
// Try multiple selectors
const videoElement = document.querySelector('#bgVideo') || 
                     document.querySelector('#bgVideoPlaceholder') ||
                     document.querySelector('video');

if (!videoElement) {
    console.warn('No video element found');
    return;
}

this.videoElement = videoElement;
```

### Finding Background Image

```javascript
const bgImageDiv = document.querySelector('#bgImage');

if (!bgImageDiv) {
    console.warn('No background image div found');
    return;
}

const computedStyle = window.getComputedStyle(bgImageDiv);
const backgroundImage = computedStyle.backgroundImage;

if (!backgroundImage || backgroundImage === 'none') {
    return;
}

// Extract URL from CSS
const urlMatch = backgroundImage.match(/url\(['"]?([^'"]+)['"]?\)/);
if (urlMatch) {
    const imageUrl = urlMatch[1];
    
    // Load image
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageUrl;
    img.onload = () => {
        this.createBackgroundTexture(img);
    };
}
```

### Creating Video Texture (Direct Mode)

For mapping video directly onto surfaces:

```javascript
this.videoTexture = new THREE.VideoTexture(videoElement);
this.videoTexture.minFilter = THREE.LinearFilter;
this.videoTexture.magFilter = THREE.LinearFilter;
this.videoTexture.mapping = THREE.UVMapping;  // Standard UV mapping
this.videoTexture.format = THREE.RGBFormat;
this.videoTexture.flipY = true;  // Correct orientation

// Apply to material
material.map = this.videoTexture;
```

### Creating Background Image Texture (Direct Mode)

```javascript
this.bgImageTexture = new THREE.Texture(imageElement);
this.bgImageTexture.needsUpdate = true;
this.bgImageTexture.mapping = THREE.UVMapping;
this.bgImageTexture.flipY = true;  // Correct orientation

// Apply to material
material.map = this.bgImageTexture;
```

---

## Cube Camera System for Video Reflections

**Why Cube Cameras?**

Three.js r120+ doesn't support video textures with EquirectangularReflectionMapping for environment maps. To get video reflections on chrome/metallic surfaces, you must use a cube camera system.

### When to Use Cube Cameras

✅ **Use Cube Cameras For:**
- Video reflections on metallic/chrome materials
- Dynamic environment mapping
- Real-time reflections that change based on object position
- Complex reflective surfaces with videos

❌ **Don't Need Cube Cameras For:**
- Static background image reflections (use EquirectangularReflectionMapping)
- Direct video textures on surfaces (use UVMapping)
- Non-reflective materials

### Complete Cube Camera Implementation

#### Step 1: Create Cube Render Target

```javascript
// High resolution for quality (4096 = 4k per cube face)
// Can reduce to 2048 or 1024 for better performance
this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(4096, {
    format: THREE.RGBAFormat,
    generateMipmaps: true,
    minFilter: THREE.LinearMipmapLinearFilter,
    magFilter: THREE.LinearFilter
});

// Set color space to match renderer
if (this.cubeRenderTarget.texture.encoding !== undefined) {
    this.cubeRenderTarget.texture.encoding = THREE.sRGBEncoding;
}
```

#### Step 2: Create Cube Camera

```javascript
// Cube camera positioned at origin
this.cubeCamera = new THREE.CubeCamera(
    0.1,   // near
    1000,  // far
    this.cubeRenderTarget
);

this.cubeCamera.position.set(0, 0, 0);

// Enable layer 1 so it can see the video sphere
this.cubeCamera.layers.enable(1);

this.scene.add(this.cubeCamera);

// Store the generated cube map texture
this.cubeMapTexture = this.cubeRenderTarget.texture;
```

#### Step 3: Create Large Video Sphere

The cube camera needs something to capture. Create a large inverted sphere textured with video:

```javascript
// Large sphere geometry (500 units radius)
const sphereGeometry = new THREE.SphereGeometry(500, 120, 80);
// Invert sphere to face inward
sphereGeometry.scale(-1, 1, 1);

// Create video texture for sphere
const videoTextureForSphere = new THREE.VideoTexture(videoElement);
videoTextureForSphere.minFilter = THREE.LinearFilter;
videoTextureForSphere.magFilter = THREE.LinearFilter;
videoTextureForSphere.mapping = THREE.EquirectangularReflectionMapping;
videoTextureForSphere.format = THREE.RGBAFormat;

// Set color space
if (videoTextureForSphere.encoding !== undefined) {
    videoTextureForSphere.encoding = THREE.sRGBEncoding;
}

// Create material
const sphereMaterial = new THREE.MeshBasicMaterial({
    map: videoTextureForSphere
});

// Create mesh
this.videoSphere = new THREE.Mesh(sphereGeometry, sphereMaterial);

// Base rotations for correct orientation
this.videoSphere.rotation.y = Math.PI / 2;        // 90 degrees
this.videoSphere.rotation.x = -35 * (Math.PI / 180);  // -35 degrees

// Set to layer 1 (hidden from main camera, visible to cube camera)
this.videoSphere.layers.set(1);
this.videoSphere.visible = true;

this.scene.add(this.videoSphere);
```

#### Step 4: Apply Cube Map to Materials

```javascript
// For chrome/metallic materials
material.map = null;  // Remove direct texture
material.envMap = this.cubeMapTexture;  // Apply cube map
material.metalness = 1.0;
material.roughness = 0.0;
material.envMapIntensity = 0.5;  // Adjust for desired reflection strength
material.needsUpdate = true;
```

#### Step 5: Update Cube Camera Every Frame

In your `onRender()` method:

```javascript
onRender(deltaTime, timestamp, sharedAudioData) {
    // Update video texture
    if (this.videoElement && !this.videoElement.paused && 
        this.videoElement.readyState >= 2) {
        
        // Update video texture on sphere
        if (this.videoSphere.material && this.videoSphere.material.map) {
            this.videoSphere.material.map.needsUpdate = true;
        }
        
        // Update cube camera (required for video reflections)
        // Hide reflective objects temporarily
        this.spheres.forEach(sphere => {
            sphere.mesh.visible = false;
        });
        
        // Make sure video sphere is visible
        this.videoSphere.visible = true;
        
        // Update cube camera from origin
        this.cubeCamera.update(this.renderer, this.scene);
        
        // Restore visibility
        this.spheres.forEach(sphere => {
            sphere.mesh.visible = true;
        });
    }
    
    // Render main scene
    this.renderer.render(this.scene, this.camera);
}
```

### Advanced: Dynamic Cube Camera Positioning

For more realistic reflections that change based on object position:

```javascript
// Calculate average position of all reflective objects
let avgX = 0, avgY = 0, avgZ = 0;
let count = 0;

this.spheres.forEach(sphere => {
    avgX += sphere.mesh.position.x;
    avgY += sphere.mesh.position.y;
    avgZ += sphere.mesh.position.z;
    count++;
});

if (count > 0) {
    avgX /= count;
    avgY /= count;
    avgZ /= count;
    
    // Move cube camera to average position
    this.cubeCamera.position.set(avgX, avgY, avgZ);
}

// Update cube camera from new position
this.cubeCamera.update(this.renderer, this.scene);
```

### Performance Optimization: Higher Quality Captures

```javascript
// Temporarily increase renderer pixel ratio for cube camera
const originalPixelRatio = this.renderer.getPixelRatio();
this.renderer.setPixelRatio(Math.min(originalPixelRatio * 2.0, 2.0));

// Update cube camera
this.cubeCamera.update(this.renderer, this.scene);

// Restore original pixel ratio
this.renderer.setPixelRatio(originalPixelRatio);
```

### Anisotropic Filtering for Quality

```javascript
// Add anisotropic filtering to cube map
const maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
if (maxAnisotropy > 0) {
    this.cubeMapTexture.anisotropy = maxAnisotropy;
}
```

---

## Layer Management

Use Three.js layers to control which objects are visible to different cameras.

### Layer Setup

```javascript
// Layer 0: Default layer (main camera sees this)
// Layer 1: Hidden from main camera (cube camera sees this)

// Set object to layer 1 (hidden from main camera)
this.videoSphere.layers.set(1);

// Enable cube camera to see layer 1 (while keeping layer 0)
this.cubeCamera.layers.enable(1);
```

### Toggling Visibility

```javascript
toggleBackgroundSphere() {
    this.bgSphereVisible = !this.bgSphereVisible;
    
    // Change layer based on visibility
    this.videoSphere.layers.set(this.bgSphereVisible ? 0 : 1);
    
    // Additional rotation when visible to user
    if (this.bgSphereVisible) {
        // Add 180° so video appears correct orientation to viewer
        this.videoSphere.rotation.y = this.videoSphereBaseRotationY + Math.PI;
    } else {
        // Use base rotation for cube camera capture
        this.videoSphere.rotation.y = this.videoSphereBaseRotationY;
    }
}
```

---

## Color Space Management

### Why sRGB Encoding Matters

To ensure video reflections match the brightness and color of background image reflections:

```javascript
// 1. Set renderer output encoding
this.renderer.outputEncoding = THREE.sRGBEncoding;

// 2. Set cube render target encoding
this.cubeRenderTarget.texture.encoding = THREE.sRGBEncoding;

// 3. Set video texture encoding
videoTexture.encoding = THREE.sRGBEncoding;
```

**Result:** Consistent color and brightness across all reflection sources.

---

## Dual Mapping Modes

Support both direct texture and reflection modes:

### Direct Mode

```javascript
if (this.mappingMode === 'direct') {
    material.map = this.videoTexture;      // Show video directly
    material.envMap = null;                // No environment map
    material.metalness = Math.min(this.metalness, 0.5);
    material.roughness = Math.max(this.roughness, 0.3);
}
```

### Reflection Mode

```javascript
if (this.mappingMode === 'reflection') {
    material.map = null;                   // No direct texture
    material.envMap = this.cubeMapTexture; // Use cube map for reflections
    material.metalness = this.metalness;
    material.roughness = this.roughness;
    material.envMapIntensity = this.envMapIntensity;
}
```

---

# Audio Integration

## Getting Audio Data

```javascript
onUpdate(deltaTime, timestamp, sharedAudioData) {
    // Get overall energy (0-1)
    const energy = this.getAudioEnergy();
    
    // Get frequency data
    const frequencies = this.getAudioFrequencies();
    
    // Get frequency bands
    this.frequencyBands = this.getFrequencyBands();
    
    // Detect beats
    const isBeat = this.detectBeat(timestamp);
    if (isBeat) {
        this.onBeat();
    }
}
```

## Frequency Bands

```javascript
getFrequencyBands() {
    const frequencies = this.getAudioFrequencies();
    
    if (!frequencies || frequencies.length === 0) {
        return { bass: 0, mid: 0, treble: 0 };
    }
    
    const length = frequencies.length;
    
    return {
        bass: this.avgRange(frequencies, 0, Math.floor(length * 0.1)),
        mid: this.avgRange(frequencies, Math.floor(length * 0.1), Math.floor(length * 0.5)),
        treble: this.avgRange(frequencies, Math.floor(length * 0.5), length)
    };
}

avgRange(arr, start, end) {
    if (!arr || arr.length === 0) return 0;
    
    let sum = 0;
    let count = 0;
    
    for (let i = start; i < end && i < arr.length; i++) {
        sum += arr[i] / 255;  // Normalize to 0-1
        count++;
    }
    
    return count > 0 ? sum / count : 0;
}
```

## Beat Detection

```javascript
// In constructor
this.currentEnergy = 0;
this.smoothedEnergy = 0;
this.energyHistory = [];
this.beatDetection = {
    lastBeatTime: 0,
    threshold: 1.3,
    minTimeBetweenBeats: 200
};

// In onUpdate
onUpdate(deltaTime, timestamp, sharedAudioData) {
    this.currentEnergy = this.getAudioEnergy();
    
    // Smooth energy
    this.energyHistory.push(this.currentEnergy);
    if (this.energyHistory.length > 30) {
        this.energyHistory.shift();
    }
    
    this.smoothedEnergy = this.energyHistory.reduce((a, b) => a + b, 0) / this.energyHistory.length;
    
    // Detect beat
    const isBeat = this.detectBeat(timestamp);
    if (isBeat && this.beatPulse) {
        this.onBeat();
    }
}

detectBeat(timestamp) {
    const energy = this.currentEnergy;
    const bd = this.beatDetection;
    const avg = this.smoothedEnergy;
    
    const timeSinceBeat = timestamp - bd.lastBeatTime;
    if (energy > avg * bd.threshold && timeSinceBeat > bd.minTimeBetweenBeats) {
        bd.lastBeatTime = timestamp;
        return true;
    }
    
    return false;
}

onBeat() {
    // React to beat - e.g., pulse spheres
    this.spheres.forEach(sphere => {
        const currentScale = sphere.mesh.scale.x;
        sphere.mesh.scale.set(currentScale * 1.2, currentScale * 1.2, currentScale * 1.2);
        
        setTimeout(() => {
            sphere.mesh.scale.set(1, 1, 1);
        }, 100);
    });
}
```

## Audio-Reactive Effects

### Scale with Bass

```javascript
if (this.audioReactive && this.bassScale) {
    const bassScale = 1 + this.frequencyBands.bass * 0.5;
    sphere.mesh.scale.set(bassScale, bassScale, bassScale);
}
```

### Movement with Mids

```javascript
if (this.audioReactive && this.midMovement) {
    const movementBoost = 1 + this.frequencyBands.mid * 3;
    sphere.mesh.position.x = sphere.basePosition.x + floatX * movementBoost;
    sphere.mesh.position.y = sphere.basePosition.y + floatY * movementBoost;
}
```

### Roughness with Treble

```javascript
if (this.audioReactive && this.trebleShine) {
    const dynamicRoughness = this.roughness * (1 - this.frequencyBands.treble * 0.5);
    sphere.mesh.material.roughness = Math.max(0.01, dynamicRoughness);
}
```

---

# UI Controls

## Button Toggles

### Setup

```javascript
this.addControl('mappingMode', {
    type: 'button',
    label: 'Reflection',
    className: 'btn-toggle active',
    onClick: () => {
        this.toggleMappingMode();
    }
});
```

### Updating Button Labels

**CRITICAL:** Use direct DOM queries with `data-control` attribute:

```javascript
toggleMappingMode() {
    this.mappingMode = this.mappingMode === 'direct' ? 'reflection' : 'direct';
    
    // Query DOM directly
    const buttonElement = document.querySelector('[data-control="mappingMode"]');
    
    if (buttonElement) {
        const newLabel = this.mappingMode === 'direct' ? 'Direct Texture' : 'Reflection';
        buttonElement.textContent = newLabel;
        
        // Toggle active class
        if (this.mappingMode === 'reflection') {
            buttonElement.classList.add('active');
        } else {
            buttonElement.classList.remove('active');
        }
    }
    
    // Apply changes
    this.applyTextureToSpheres();
}
```

## Sliders

### Basic Slider

```javascript
this.addControl('size', {
    type: 'slider',
    label: 'Size',
    min: 5.0,
    max: 10.0,
    step: 0.1,
    value: this.maxSize,
    onChange: (value) => {
        this.maxSize = value;
        this.updateSphereSizes();
    }
});
```

### Slider with Units

```javascript
this.addControl('floatSpeed', {
    type: 'slider',
    label: 'Float Speed',
    min: 0,
    max: 10,
    step: 0.1,
    value: this.floatSpeed,
    unit: 'x',  // Shows "5.0x" instead of just "5.0"
    onChange: (value) => {
        this.floatSpeed = value;
    }
});
```

## Checkboxes

```javascript
this.addControl('audioReactive', {
    type: 'checkbox',
    label: 'Audio Reactive',
    checked: this.audioReactive,
    onChange: (checked) => {
        this.audioReactive = checked;
    }
});
```

---

# Performance Optimization

## Cube Camera Performance

### Resolution Trade-offs

```javascript
// Ultra quality (expensive)
this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(4096, {...});

// High quality (balanced)
this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(2048, {...});

// Good quality (performance)
this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(1024, {...});
```

**GPU Memory Usage:**
- 4096: ~402 MB per cube camera
- 2048: ~100 MB per cube camera  
- 1024: ~25 MB per cube camera

### Update Frequency

```javascript
// Update every frame (best quality, expensive)
this.cubeCamera.update(this.renderer, this.scene);

// Update every N frames (good balance)
if (this.frameCount % 2 === 0) {  // Every other frame
    this.cubeCamera.update(this.renderer, this.scene);
}
this.frameCount++;
```

### Shared vs Per-Object Cube Cameras

```javascript
// ✅ RECOMMENDED: Shared cube camera with dynamic positioning
// Cost: 1 cube camera update per frame × 6 render passes = 6 renders/frame
this.cubeCamera.position.set(avgX, avgY, avgZ);
this.cubeCamera.update(this.renderer, this.scene);

// ❌ EXPENSIVE: Per-object cube cameras
// Cost: N cube cameras × 6 render passes = 6N renders/frame
this.spheres.forEach(sphere => {
    sphere.cubeCamera.position.copy(sphere.mesh.position);
    sphere.cubeCamera.update(this.renderer, this.scene);
});
```

## Geometry Optimization

### Sphere Detail Levels

```javascript
// Ultra quality (heavy)
const geometry = new THREE.SphereGeometry(size, 64, 64);  // 4096 faces

// High quality (balanced)
const geometry = new THREE.SphereGeometry(size, 32, 32);  // 1024 faces

// Good quality (performance)
const geometry = new THREE.SphereGeometry(size, 16, 16);  // 256 faces
```

### Geometry Instancing

For many similar objects:

```javascript
const geometry = new THREE.SphereGeometry(1, 32, 32);
const material = new THREE.MeshStandardMaterial({...});

const instancedMesh = new THREE.InstancedMesh(geometry, material, count);

// Set positions
for (let i = 0; i < count; i++) {
    const matrix = new THREE.Matrix4();
    matrix.setPosition(x, y, z);
    instancedMesh.setMatrixAt(i, matrix);
}

instancedMesh.instanceMatrix.needsUpdate = true;
this.scene.add(instancedMesh);
```

## General Performance Tips

### Minimize State Changes

```javascript
// ❌ BAD: Change material every frame
this.spheres.forEach(sphere => {
    sphere.mesh.material.roughness = newValue;
    sphere.mesh.material.needsUpdate = true;
});

// ✅ GOOD: Only update when value actually changes
if (this.roughness !== newRoughness) {
    this.roughness = newRoughness;
    this.updateSphereMaterials();
}
```

### Conditional Updates

```javascript
// Only update when necessary
if (this.mappingMode === 'reflection' && 
    this.envMapSource === 'video' && 
    this.videoElement && 
    !this.videoElement.paused) {
    this.cubeCamera.update(this.renderer, this.scene);
}
```

### Disposal

```javascript
onCleanup() {
    // Dispose geometries
    this.spheres.forEach(sphere => {
        sphere.mesh.geometry.dispose();
        sphere.mesh.material.dispose();
    });
    
    // Dispose textures
    if (this.videoTexture) this.videoTexture.dispose();
    if (this.cubeMapTexture) this.cubeMapTexture.dispose();
    if (this.cubeRenderTarget) this.cubeRenderTarget.dispose();
    
    // Dispose renderer
    if (this.renderer) {
        this.renderer.dispose();
    }
}
```

---

# Best Practices

## Do's

✅ Get dimensions from `visualizationContainer`
✅ Use individual CSS property assignment (not cssText)
✅ Set `width: 100%` and `height: 100%` for responsive sizing
✅ Use `devicePixelRatio` for high-DPI displays
✅ Use sRGB color space throughout
✅ Dispose resources in `onCleanup()`
✅ Use direct DOM queries for control updates
✅ Add comprehensive comments
✅ Test on different devices and browsers

## Don'ts

❌ Use canvas buffer dimensions for renderer size
❌ Copy cssText from base canvas
❌ Use fixed pixel dimensions in CSS
❌ Forget to update video textures every frame
❌ Create per-object cube cameras without considering performance
❌ Forget to hide objects during cube camera capture
❌ Mix color spaces (LinearEncoding vs sRGBEncoding)
❌ Update cube cameras when not in reflection mode

## Common Pitfalls

### 1. Canvas Sizing
**Problem:** Three.js canvas appears at wrong size

**Solution:** Get size from container, use percentage CSS

### 2. Video Reflections Not Working
**Problem:** Video doesn't appear in chrome reflections

**Solution:** Implement cube camera system (required for Three.js r120+)

### 3. Upside-Down Textures
**Problem:** Video or images appear inverted

**Solution:** Use `flipY = true` instead of rotation

### 4. Color Mismatch
**Problem:** Video reflections look different from image reflections

**Solution:** Use consistent sRGB encoding throughout

### 5. Performance Issues
**Problem:** Frame rate drops with video reflections

**Solution:** Reduce cube map resolution, update less frequently, or use shared cube camera

---

# Complete Example: Chrome Spheres with Video Reflections

See the Chrome Spheres plugin for a complete working implementation of:
- Cube camera system
- Dynamic positioning
- Layer management
- Dual mapping modes
- Audio reactivity
- Button toggle updates
- Performance optimization

Study that plugin as the reference implementation for advanced Three.js techniques in Freque.

---

# Additional Resources

## Three.js Documentation
- [Three.js Docs](https://threejs.org/docs/)
- [Three.js Examples](https://threejs.org/examples/)
- [CubeCamera](https://threejs.org/docs/#api/en/cameras/CubeCamera)
- [WebGLCubeRenderTarget](https://threejs.org/docs/#api/en/renderers/WebGLCubeRenderTarget)

## Freque Resources
- Creating Plugins with Claude Guide
- Example Plugins in `js/plugins/`
- Freque Discord Community

---

**Happy plugin development! 🚀🎨🎵**

*Guide Version 2.0 - Updated with cube camera system documentation*
