# Chrome Spheres Plugin - Version Comparison & Analysis

## Executive Summary

The Chrome Spheres plugin has undergone significant architectural improvements from v1.2.0 to v1.3.0, primarily focused on solving the fundamental challenge of rendering video textures on reflective chrome surfaces in Three.js r120+.

**Key Achievement:** Successfully implemented dynamic cube camera-based video reflection mapping, a sophisticated technique required for modern Three.js versions that don't support direct video environment mapping.

---

## Major Architectural Changes

### 1. Cube Camera System for Video Reflections (NEW in v1.3.0)

**Problem Solved:**
Three.js r120+ doesn't support direct video textures with EquirectangularReflectionMapping for environment maps. Static images work fine, but videos require a different approach.

**Solution Implemented:**
- Created a large inverted sphere (500 unit radius) textured with the video
- Positioned a CubeCamera at the origin to capture this sphere from all angles
- Generated a dynamic cube map texture every frame
- Applied this cube map as the environment map on the chrome spheres

**Technical Details:**
```javascript
// Cube render target with maximum resolution (4096x4096 per face)
this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(4096, {
    format: THREE.RGBAFormat,
    generateMipmaps: true,
    minFilter: THREE.LinearMipmapLinearFilter,
    magFilter: THREE.LinearFilter
});

// Cube camera positioned at origin
this.cubeCamera = new THREE.CubeCamera(0.1, 1000, this.cubeRenderTarget);
this.cubeCamera.position.set(0, 0, 0);

// Large inverted video sphere
const sphereGeometry = new THREE.SphereGeometry(500, 120, 80);
sphereGeometry.scale(-1, 1, 1); // Invert to face inward
```

### 2. Dynamic Cube Camera Positioning (NEW)

**Innovation:**
The cube camera position dynamically updates to the average position of all spheres, creating more realistic reflections that change based on sphere positions.

**Implementation:**
```javascript
// Calculate average position of all spheres
let avgX = 0, avgY = 0, avgZ = 0;
this.spheres.forEach(sphere => {
    avgX += sphere.mesh.position.x;
    avgY += sphere.mesh.position.y;
    avgZ += sphere.mesh.position.z;
});
avgX /= this.spheres.length;
avgY /= this.spheres.length;
avgZ /= this.spheres.length;

// Update cube camera to average position
this.cubeCamera.position.set(avgX, avgY, avgZ);
```

**Performance Note:**
Per-sphere cube cameras were explored (`this.usePerSphereCubeCameras`) but disabled by default due to performance cost. The shared camera with dynamic positioning provides excellent quality with minimal overhead.

### 3. Background Sphere Visibility Control (NEW)

**Feature:**
Users can now toggle visibility of the large video sphere that provides the reflection source.

**Technical Implementation:**
```javascript
// Layer 0 = visible to main camera
// Layer 1 = hidden from main camera (but visible to cube camera)
this.videoSphere.layers.set(this.bgSphereVisible ? 0 : 1);

// Cube camera always sees layer 1
this.cubeCamera.layers.enable(1);
```

**Rotation Correction:**
When background sphere is visible, it gets an additional 180° rotation so viewers see the video correctly oriented (not inverted).

### 4. Dual Texture System

**Architecture:**
Maintains separate textures for different mapping modes and sources:

```javascript
// For Video Source
this.videoTexture = null;              // UVMapping (direct mode)
this.cubeMapTexture = null;            // Cube map (reflection mode)

// For Background Image Source
this.bgImageTexture = null;            // UVMapping (direct mode)
this.bgImageTextureReflection = null;  // EquirectangularReflectionMapping
```

**Why This Works:**
- Static images: Can use EquirectangularReflectionMapping directly
- Videos: Require cube camera system for reflections
- Direct mode: Both use UVMapping with flipY for correct orientation

### 5. Color Space Management (NEW)

**sRGB Encoding Throughout:**
```javascript
// Renderer
this.renderer.outputEncoding = THREE.sRGBEncoding;

// Cube render target
this.cubeRenderTarget.texture.encoding = THREE.sRGBEncoding;

// Video texture on sphere
videoTextureForSphere.encoding = THREE.sRGBEncoding;
```

**Purpose:**
Ensures video reflections have the same brightness and color accuracy as background image reflections by maintaining consistent color space throughout the pipeline.

### 6. Enhanced Quality Settings

**High-Resolution Cube Maps:**
- 4096x4096 per cube face (previous version used 1024x1024 or 2048x2048)
- Significantly improved reflection quality

**Anisotropic Filtering:**
```javascript
const maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
this.cubeMapTexture.anisotropy = maxAnisotropy;
```

**Double Pixel Ratio for Cube Camera Captures:**
```javascript
// Temporarily increase quality during cube camera update
this.renderer.setPixelRatio(Math.min(originalPixelRatio * 2.0, 2.0));
this.cubeCamera.update(this.renderer, this.scene);
this.renderer.setPixelRatio(originalPixelRatio);
```

### 7. Video Sphere Rotation Control

**Base Rotations:**
```javascript
this.videoSphereBaseRotationY = Math.PI / 2;  // 90 degrees
this.videoSphereBaseRotationX = -35 * (Math.PI / 180);  // -35 degrees
```

**Purpose:**
- Y rotation: Aligns video orientation for correct reflections
- X rotation: Tilts video sphere for optimal viewing angle
- These rotations are temporarily restored during cube camera captures
- Additional 180° rotation applied when sphere is visible to user

---

## Control Changes

### New Controls (v1.3.0)
1. **Bg Sphere Toggle** - Show/hide the large video sphere
   - OFF: Only see reflections on chrome spheres
   - ON: See both chrome spheres AND the background video sphere

### Modified Controls
1. **Sphere Count** - Expanded range: 1-50 (was 1-30)
2. **Max Size** - Expanded range: 5.0-10.0 (was 1.0-5.0)
3. **Float Speed** - Expanded range: 0-10 with custom scaling
   - 0 = frozen
   - 10 = double speed
4. **Reflection Intensity** (formerly "Video Intensity")
   - Range: 0.0-3.0
   - Default: 0.5 for realistic chrome look

### Control Updates Fixed
All button toggles now properly update labels using direct DOM queries:
```javascript
const buttonElement = document.querySelector('[data-control="mappingMode"]');
buttonElement.textContent = newLabel;
```

---

## Performance Optimizations

### 1. Cube Camera Update Strategy
**Conditional Updates:**
- Only updates when in reflection mode
- Only updates when video source is selected
- Only updates when video is actually playing

```javascript
if (this.mappingMode === 'reflection' && 
    this.envMapSource === 'video' && 
    this.videoSphere) {
    // Update cube camera
}
```

### 2. Visibility Management
**Sphere Hiding During Cube Camera Capture:**
```javascript
// Hide spheres so they don't appear in their own reflections
this.spheres.forEach(sphere => sphere.mesh.visible = false);
this.cubeCamera.update(this.renderer, this.scene);
this.spheres.forEach(sphere => sphere.mesh.visible = true);
```

### 3. Single Shared Cube Camera
Instead of per-sphere cube cameras (which would require N updates per frame), uses one shared camera that updates to average sphere position.

**Cost:**
- Old approach (per-sphere): N cube camera updates × 6 render passes each
- New approach (shared): 1 cube camera update × 6 render passes

---

## Bug Fixes Carried Forward from v1.2.0

### 1. Proper Selector Usage
✅ Uses `#bgVideo` and `#bgVideoPlaceholder` for video
✅ Uses `#bgImage` for background images (with CSS extraction)

### 2. Canvas Setup
✅ Gets dimensions from `#visualizationContainer` not canvas buffer
✅ Sets individual CSS properties (not cssText)
✅ Uses `width: 100%` and `height: 100%`
✅ Sets proper `devicePixelRatio`

### 3. Texture Orientation
✅ Uses `flipY = true` instead of rotation
✅ Prevents upside-down textures

---

## Code Quality Improvements

### 1. Extensive Comments
Every major section now includes detailed comments explaining:
- What the code does
- Why it's necessary
- How it works with Three.js

### 2. Console Logging
Strategic console logs for debugging:
- Cube camera setup
- Texture updates
- Video element state
- Background sphere toggles

### 3. Organized Structure
Clear separation of concerns:
- Texture creation methods
- Sphere management methods
- Update/render methods
- Audio analysis methods

---

## Remaining Considerations

### 1. Performance Monitoring
With 4096x4096 cube maps updating every frame, monitor performance on:
- Lower-end GPUs
- Mobile devices
- High sphere counts (40-50 spheres)

**Potential Optimization:**
- Reduce cube map resolution for mobile
- Update cube camera every N frames instead of every frame
- Lower max sphere count on mobile

### 2. Memory Management
Large cube render targets consume significant GPU memory:
- 4096² × 6 faces × 4 bytes (RGBA) = ~402MB per cube camera

**Current Mitigation:**
- Uses single shared cube camera
- Per-sphere cameras disabled by default

### 3. Video Format Compatibility
Different video formats may behave differently with:
- Color space encoding
- Texture updates
- Performance

**Testing Recommended:**
- H.264 vs VP9 vs AV1
- Different resolutions
- Different frame rates

---

## Architectural Lessons Learned

### 1. Three.js Version Compatibility
Modern Three.js (r120+) requires cube cameras for video environment mapping. This is a fundamental limitation, not a bug.

### 2. Color Space Matters
Consistent sRGB encoding throughout the pipeline is critical for matching reflection brightness between video and static images.

### 3. Layer System is Powerful
Using layers (0 for main camera, 1 for cube camera) elegantly solves the visibility problem without manual show/hide toggling.

### 4. Quality vs Performance Trade-off
4096 cube maps look amazing but cost performance. The option exists to reduce this for production use.

---

## Documentation Impact

### Updates Needed for Development Guide
1. Add section on cube camera-based video reflection mapping
2. Explain layer system usage for selective visibility
3. Document sRGB color space requirements
4. Add performance considerations for cube maps
5. Include example of dynamic cube camera positioning

### Updates Needed for Claude Guide
1. Add prompt example for video reflection systems
2. Include guidelines for cube camera implementation
3. Explain when to use cube cameras vs direct mapping
4. Add troubleshooting for video texture issues

---

## Conclusion

The v1.3.0 Chrome Spheres plugin represents a sophisticated solution to a complex technical challenge. The cube camera system, while more complex than simple texture mapping, is the correct architectural approach for video reflections in modern Three.js.

**Key Achievements:**
✅ Video reflections working correctly
✅ Maintained performance with single shared cube camera
✅ High quality 4096 cube maps
✅ Proper color space management
✅ User control over background sphere visibility
✅ Dynamic positioning for realistic reflections

**Technical Sophistication:**
This plugin demonstrates advanced Three.js techniques including:
- Cube camera systems
- Layer management
- Dynamic texture updates
- Inverted sphere geometry
- Color space encoding
- Performance optimization strategies

The plugin is now production-ready and serves as an excellent reference implementation for other plugins requiring video-based environment mapping.
